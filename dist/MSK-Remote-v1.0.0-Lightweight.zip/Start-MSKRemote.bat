@echo off
cd /d "%~dp0"
start "" "MSKRemote.exe"
